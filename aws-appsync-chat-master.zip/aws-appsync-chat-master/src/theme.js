const primary = 'rgb(255, 235, 59)'
const lightBg = 'rgba(255, 235, 59, .2)'

export {
  primary,
  lightBg
}